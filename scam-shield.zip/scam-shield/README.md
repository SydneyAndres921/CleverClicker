# 🛡️ Scam Shield

An interactive site that helps people practice spotting scams safely: a quick **Test**, a **Practice** mode with clue-hunting, and deep-dive **Learn** guides.

## Run it
Open `index.html` in a browser, or use the VS Code **Live Server** extension (right-click `index.html` → *Open with Live Server*).
It also works on GitHub Pages (Settings → Pages → deploy from the main branch, root folder).

## Project layout
```
index.html            page skeleton + the list of script files
css/style.css         all colors, fonts and layout
js/app.js             the logic (router, clicks, Test/Practice/Learn pages)
js/scenarios/
  _start.js           creates the empty SCENARIOS list (keep first!)
  email.js            Phishing email
  sms.js              Text message scam
  popup.js            Fake virus warning
  call.js             Grandchild in trouble
```

## Add a scenario
1. Copy an existing file in `js/scenarios/` (e.g. `sms.js`) and rename it (e.g. `romance.js`).
2. Change the id, name, mock-up `html`, `flags` (clues), `acts` (choices) and guide text.
   - Every `data-a="x"` in the html needs an `x` entry in `acts`.
   - Every `data-f="x"` needs an `x` entry in `flags`.
   - In `acts`, `0` = unsafe choice, `1` = safe choice.
3. Add one line to `index.html`, before `js/app.js`:
   `<script src="js/scenarios/romance.js"></script>`

It then appears on the Test, Practice and Learn pages automatically.

## Team workflow
- Pull before you start (`git pull`), commit small changes, push often.
- Work on a branch for bigger changes and open a Pull Request.
- Each scenario is its own file, so two people rarely edit the same lines.
